/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ders2;

/**
 *
 * @author Fatih
 */
public class Oyuncu {
    
    public String AdSoyad;
    public int puan;
    
    public Oyuncu(String ad, int p){
        AdSoyad = ad;
        puan = p;
    }
    
    public String ToString(){
        return AdSoyad + " - " + puan;
    }
    
}
