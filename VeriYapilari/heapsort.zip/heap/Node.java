/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heap;

/**
 *
 * @author BilgMuh
 */
public class Node {
    
    public int value;
    public Node left;
    public Node right;
    public Node parent;
    public int index;
    public int level;
    
    public Node(int val)
    {
        value = val;
    }
}
