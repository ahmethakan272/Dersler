/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package avltrees;

/**
 *
 * @author Fatih
 */
public class AVLTrees {

    /**
     * @param args the command line arguments
     */
    
    Node root;
    
    public void Insert(Node parent, int val)
    {
        Node newNode = new Node(val);
        if(root == null)
        {
            root = newNode;
        }
        else
        {
            if(val < parent.value)
            {
                if(parent.left == null)
                    parent.left = newNode;
                else
                    Insert(parent.left, val);
            }
            else
            {
                if(parent.right == null)
                    parent.right = newNode;
                else
                    Insert(parent.right, val);
            }
        } 
        
//        if(isBlanceCorrupted() == true)
//        {
//            
//        }
//     currentNode
        
    }
    
//    public boolean isBlanceCorrupted()
//    {
//        
//    }
    
    public void inOrder(Node parent, boolean isMin, int level)
    {
        if(parent != null)
        {
            inOrder(parent.left, isMin, level +1);
            parent.level = level;
            System.out.println(parent.value + " - " + parent.level);
            inOrder(parent.right, isMin, level +1);
        }
        
        
    }
    
    
    public int min = 1000;
    public void GetmMin()
    {
        inordMin(root);
    }
    
    public int max = 0;
    public void GetmMax()
    {
        inordMax(root);
    }
    
    public void inordMin(Node dugum)
    {
        if(dugum != null)
        {
                inordMin(dugum.left);
                if(dugum.left == null || dugum.right == null)
                {
                    if (min > dugum.level)
                        min = dugum.level;
                }
                inordMin(dugum.right);
        }
            
    }
    
    
    public void inordMax(Node dugum)
    {
        if(dugum != null)
        {
                inordMax(dugum.left);
                if(dugum.left == null || dugum.right == null)
                {
                    if (min < dugum.level)
                        min = dugum.level;
                }
                inordMax(dugum.right);
        }
            
    }
    
    
    
    
    
}
