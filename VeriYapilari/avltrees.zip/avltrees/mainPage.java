/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package avltrees;

/**
 *
 * @author Fatih
 */
public class mainPage {
    public static void main(String[] args) {
        // TODO code application logic here
        AVLTrees tree = new AVLTrees();
        tree.Insert(tree.root, 5);
        tree.Insert(tree.root, 10);
        tree.Insert(tree.root, 15);
        tree.Insert(tree.root, 11);
        tree.Insert(tree.root, 6);
        tree.Insert(tree.root, 4);
        tree.Insert(tree.root, 3);
        
        tree.inOrder(tree.root, true, 0);
        
        tree.GetmMin();
        tree.GetmMax();
        
        System.out.println(tree.max - tree.min);
    }
}
