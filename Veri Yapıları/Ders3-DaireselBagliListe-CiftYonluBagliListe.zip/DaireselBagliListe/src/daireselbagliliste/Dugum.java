/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daireselbagliliste;

/**
 *
 * @author Fatih
 */
public class Dugum {
    
    public int deger;
    public Dugum sonraki;
    
    public Dugum(int deger){
        
        this.deger = deger;
    }
    
}
