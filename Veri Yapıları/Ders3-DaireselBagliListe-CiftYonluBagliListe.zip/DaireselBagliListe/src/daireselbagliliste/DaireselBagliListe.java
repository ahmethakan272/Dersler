/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daireselbagliliste;

/**
 *
 * @author Fatih
 */
public class DaireselBagliListe {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        DBagliListe daireselBagli = new DBagliListe();
        
        daireselBagli.Ekle(10);
        daireselBagli.Ekle(5);
        daireselBagli.Ekle(8);
        daireselBagli.Ekle(7);
        
        daireselBagli.Sil(5);
        System.out.print(daireselBagli.DugumBul(5));
    }
    
}
